#!/usr/bin/env bash
echo watch mode
