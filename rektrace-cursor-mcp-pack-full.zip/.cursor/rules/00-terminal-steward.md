# Terminal Steward Protocol
PLAN → COMMAND → RUN → OUTPUT → VERDICT → NEXT.
