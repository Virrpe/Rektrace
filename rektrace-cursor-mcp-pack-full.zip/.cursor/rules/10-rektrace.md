# RekTrace Tight Loop
Always paste terminal output and exit codes.
