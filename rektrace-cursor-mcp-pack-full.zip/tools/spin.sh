#!/usr/bin/env bash
echo spinning
